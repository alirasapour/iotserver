const healthUser = require('../models/healthuser')
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
require("dotenv").config();

module.exports = function (app) {

  app.post("/health/register", async (req, res) => {
    console.log("/register user from App.")
    try {
      const { first_name, last_name, mobile, age, height, weight, password, blood } = req.body;
      if (!(mobile && password && first_name && last_name && blood && age && height && weight)) {
        return res.json("لطفا تمامی کادر هارا وارد نمایید.");
      }
      if(mobile && password && first_name && last_name && blood && age && height && weight =="undefined"){
        res.json("لطفا تمامی کادر هارا وارد نمایید.");
        return ;
      }
      if(!(age <= 140)){
        res.json("سن وارد شده صحیح نمی باشد.");
        return ;
      }
      if(!(weight <= 280)){
        res.json("وزن وارد شده صحیح نمی باشد.");
        return ;
      }
      if(height < 90 || height > 235){
        res.json("قد شما صحیح نمی باشد.");
        return ;
      }
      const oldUser = await healthUser.findOne({ mobile });
      if (oldUser) {
        return res.json("شما قبلا با این شماره تلفن ثبت نام کرده اید.");
      }
      encryptedPassword = password;
      // encryptedPassword = await bcrypt.hash(password, 10);
      const user = await healthUser.create({
        first_name,
        last_name,
        age,
        mobile,
        blood,
        weight,
        height,
        password: encryptedPassword,
      });
      const token = jwt.sign(
        { mobile, password },
        process.env.TOKEN_KEY,
        {
          expiresIn: "380d",
        }
      );
      // save user token
      user.token = token;
      // return new user
      res.json(user);
    } catch (err) {
      console.log(err);
    }
    // Break herer

    // Our register logic ends here
  });


  app.post("/health/login", async (req, res) => {
    try {
      const { mobile, password } = req.body;
      if (!(mobile && password)) {
        return res.json("لطفا تمامی کادر هارا وارد نمایید.");
      }
      const user = await healthUser.findOne({ mobile });
      if (user && user.password == password) {
        const token = jwt.sign(
          { user_id: user._id, mobile },
          process.env.TOKEN_KEY,
          {
            expiresIn: "380d",
          }
        );

        user.token = token;
        res.status(200).json(user);
      }
      res.status(400).send("Invalid Credentials");
    } catch (err) {
      console.log(err);
    }
    
  });


}