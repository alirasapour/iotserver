
const mongoose = require("mongoose");

const healthUser = new mongoose.Schema({
  first_name: { type: String, default: null },
  last_name: { type: String, default: null },
  mobile: { type: String, unique: true },
  password: { type: String },
  age : {type : String},
  height: {type : String,},
  weight : {type : String},
  blood : {type : String},
  token: { type: String },
});

module.exports = mongoose.model("healthUser", healthUser);
