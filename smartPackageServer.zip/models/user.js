
const mongoose = require("mongoose");

const user = new mongoose.Schema({
  consumer: { type: String, default: null },
  installer : {type : String},
  serial: {type : String,},
  service: {type : String,},
  pump_status : {type : Boolean},
  air: { type: Boolean },
  in_pressure: { type: Number },
  out_pressure: { type: Number },
  water_status: {type : Boolean,},
  smoke: { type: Boolean },
  in_flow: { type: Number },
  temp : {type : Number}
});

module.exports = mongoose.model("user", user);
