
const mongoose = require("mongoose");

const user = new mongoose.Schema({
  consumer: { type: String, default: null },
  installer: { type: String, default: null },
  serial: { type: String, default: null },
  mobile: { type: String },
  service: { type: String, default: null },
  pump_status: { type: Boolean, default: false },
  air: { type: Boolean, default: false },
  water_status: { type: Boolean, default: null },
  smoke: { type: Boolean, default: false },
  temp: { type: Number, default: 0 },
  in_temp: { type: Number, default: 0 },
  out_temp: { type: Number, default: 0 },
  pac_temp: { type: Number, default: 0 },
  in_pressure: { type: Number, default: 0 },
  out_pressure: { type: Number, default: 0 },
  pac_pressure: { type: Number, default: 0 },
  in_flow: { type: Number, default: 0 },
  out_flow: { type: Number, default: 0 },
  pac_flow: { type: Number, default: 0 },
  issummer: { type: Boolean, default: false },
  status: { type: Number, default: 0 },
  alarm: { type: Number, default: 0 },
  isdegree: { type: Boolean, default: false },
  temp_setted: { type: Number, default: 0 },
  token: { type: String },
  sms_token: { type: String },
});

module.exports = mongoose.model("user", user);
