const mongoose = require('mongoose');
const IRSchema = new mongoose.Schema({
    value: {
        type: Number,
        required: true
    },
    mobile: {
        type: String,
        required: true
    },
    time: {
        type: Date,
        default: Date.now
    }
});
const Ir = mongoose.model('IR', IRSchema);

module.exports = Ir;