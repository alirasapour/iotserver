'use strict';
$(document).ready(function () {

    $('.js-example-basic-single').select2({
        placeholder: 'انتخاب'
    });

});