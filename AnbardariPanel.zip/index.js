const express = require("express");
var bodyParser = require("body-parser");
const path = require("path");
const bcrypt = require('bcrypt');
const passport = require("passport");
require('./config/passport')(passport)
const app = express();
const { MongoClient } = require("mongodb");
const mongoose = require('mongoose');
const User = require('./models/user');
const expressEjsLayout = require('express-ejs-layouts')
const flash = require('connect-flash');
const session = require('express-session');
var compression = require('compression')
app.use(express.urlencoded({ extended: false }));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
process.env.PWD = process.cwd();
app.use('/img', express.static(path.join(__dirname, 'public/img')));
app.use('/plugins', express.static(path.join(__dirname, 'public/plugins')));
app.use('/dist', express.static(path.join(__dirname, 'public/dist')));
app.use(express.json());
app.use(express.urlencoded());
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use(compression())
const port = 3000;
const { ensureAuthenticated } = require('./config/auth')
mongoose.connect('mongodb://localhost/data', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('[+] Connected to MongoDB .'))
  .catch((err) => console.log(err));


console.clear();

//Model
const categoryModel = require('./models/category')

app.get('/anbardari/dashboard', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/dashboard', {
    user: req.user
  });
})

app.get('/anbardari/newKala', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewKala', {
    user: req.user
  });
})

app.get('/anbardari/newAnbar', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewAnbar', {
    user: req.user
  });
})

app.get('/anbardari/newVahed', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewVahed', {
    user: req.user
  });
})

app.get('/anbardari/newRanande', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewRanande', {
    user: req.user
  });
})

app.get('/anbardari/newMoshtari', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewMoshtari', {
    user: req.user
  });
})

app.get('/anbardari/newDasteBandi', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/NewDasteBandi', {
    user: req.user
  });
})

app.get('/anbardari/listVahed', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/ListVahed', {
    user: req.user
  });
})

app.get('/anbardari/listAnbar', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/ListAnbar', {
    user: req.user
  });
})

app.get('/anbardari/listRanande', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/listRanande', {
    user: req.user
  });
})

app.get('/anbardari/listMoshtari', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/ListMoshtari', {
    user: req.user
  });
})

 app.get('/anbardari/listDasteBandi', ensureAuthenticated,async (req, res) => {
  const Categories = await categoryModel.find({});
  res.render('anbardari/pages/ListDasteBandi', {
    user: req.user,
    Categories
  });
})

app.get('/anbardari/camera', ensureAuthenticated, (req, res) => {
  res.render('anbardari/pages/Camera', {
    user: req.user
  });
})

app.get('/anbardari/about', ensureAuthenticated,  (req, res) => {
  res.render('anbardari/pages/About', {
    user: req.user
  });
})

app.post("/anbardari/addCategory", async (request, res) => {
 
  const category = new categoryModel(request.body);

  try {
    await category.save();
    const Categories = await categoryModel.find({});
    res.render('anbardari/pages/ListDasteBandi', { msg: 'دسته بندی با موفقیت ایجاد گردید.',Categories});
  } catch (error) {
    res.status(500).send(error);
  }
});


app.get('/', ensureAuthenticated, (req, res) => {
  res.render('pages/index', {
    user: req.user
  });
})

app.post('/login', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login',
    failureFlash: true,

  })(req, res, next)
})


app.get("/login", function (req, res) {
  res.render("pages/login");
});

app.get("/register", function (req, res) {
  res.render("pages/register");
});


app.post('/register', (req, res) => {
  const { name, email, password, password2 } = req.body;
  let errors = [];
  console.log(' Name ' + name + ' email :' + email + ' pass:' + password);
  if (!name || !email || !password || !password2) {
    errors.push({ msg: "Please fill in all fields" })
  }
  //check if match
  if (password !== password2) {
    errors.push({ msg: "passwords dont match" });
  }

  //check if password is more than 6 characters
  if (password.length < 6) {
    errors.push({ msg: 'password atleast 6 characters' })
  }
  if (errors.length > 0) {
    res.render('register', {
      errors: errors,
      name: name,
      email: email,
      password: password,
      password2: password2
    })
  } else {
    //validation passed
    User.findOne({ email: email }).exec((err, user) => {
      console.log(user);
      if (user) {
        errors.push({ msg: 'email already registered' });
        res.render('pages/register', { errors, name, email, password, password2 })
      } else {
        const newUser = new User({
          name: name,
          email: email,
          password: password
        });

        //hash password
        bcrypt.genSalt(10, (err, salt) =>
          bcrypt.hash(newUser.password, salt,
            (err, hash) => {
              if (err) throw err;
              //save pass to hash
              newUser.password = hash;
              newUser.save()
                .then((value) => {
                  console.log(value)
                  req.flash('success_msg', 'You have now registered!');
                  res.redirect('/login');
                })
                .catch(value => console.log(value));
            }));
      }
    })
  }
})


app.get('/logout', (req, res) => {
  req.logout();
  req.flash('success_msg', 'Now logged out');
  res.redirect('/login');
})


app.post("/", function (req, res) {
  console.dir(req.body.value);
  res.send("Got a POST request");
});

app.listen(port, () => {
  console.log(`\n[+] Server listening at http://localhost:${port}`);
});

app.get("/getopt1", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();
      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "operator1" };
      const options = {
        sort: { rating: -1 },
        projection: { _id: 0, x: 1, y: 1 },
      };
      const data = await iot.findOne(query, options);
      res.status(200).send((data));
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});


app.get("/getlift1", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "liftTruck1" };
      const options = {
        sort: { rating: -1 },
        projection: { _id: 0, x: 1, y: 1 },
      };
      const data = await iot.findOne(query, options);
      res.status(200).send((data));
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});

app.get("/geta", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "a" };
      const options = {
        // sort matched documents in descending order by rating
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);

});

app.get("/getb", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "b" };
      const options = {
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});

app.post("/setc", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();
      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "c" };
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: req.body.value
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});



app.get("/setLED1on", function (req, res) {
  setLED1on();
  res.render("pages/index", { title: "Hey", message: "Hello there!" });
});


app.get("/setLED1off", function (req, res) {
  setLED1off();
  res.render("pages/index", { title: "Hey", message: "Hello there!" });
});

function setLED1on() {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();
      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "LED1" };
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: 1
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);

}
function setLED1off() {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "LED1" };
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: 0
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
}


app.get("/getLED1Status", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "LED1" };
      const options = {
        sort: { rating: -1 },
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);

});