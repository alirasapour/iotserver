
const express = require("express");
var bodyParser = require("body-parser");
const path = require("path");
const app = express();
const { MongoClient } = require("mongodb");
app.use(bodyParser.urlencoded({ extended: false }));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static('public'))
app.use(express.json());       // to support JSON-encoded bodies
app.use(express.urlencoded()); 
const port = 3000;
var assert = require("assert");
console.clear();

app.get("/", function (req, res) {
  res.render("pages/index", { title: "Hey", message: "Hello there!" });
});

app.post("/", function (req, res) {
  console.dir(req.body.value);
  res.send("Got a POST request");
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

app.get("/getopt1", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();
      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "operator1" };
      const options = {
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, x: 1,y:1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data));
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});


app.get("/getlift1", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "liftTruck1" };
      const options = {
        // sort matched documents in descending order by rating
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, x: 1,y:1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data));
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});

app.get("/geta", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "a" };
      const options = {
        // sort matched documents in descending order by rating
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);

});

app.get("/getb", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "b" };
      const options = {
        // sort matched documents in descending order by rating
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
});

app.post("/setc", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "c" };
      // this option instructs the method to create a document if no documents match the filter
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: req.body.value
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);




  // MongoClient.connect(
  //       "mongodb://localhost:27017",
  //       {
  //         useUnifiedTopology: true,
  //         // type: 'ReplicaSetNoPrimary'
  //       },
  //       (err, client) => {
  //         if (err) return console.error("EEERER" + err);
  //         const db = client.db("data");
  //         const collection = db.collection("iot");
  //         collection.updateOne(
  //           { key: "c" },
  //           { $set: { value: req.body.value } },
  //           function (err, result) {
  //             console.log("SET C");
  //           }
  //         );
  //         db.close();
  //       }
  //     );

});










app.get("/setLED1on", function (req, res) {
  setLED1on();
  res.render("pages/index", { title: "Hey", message: "Hello there!" });
});

app.get("/setLED1off", function (req, res) {
  setLED1off();
  res.render("pages/index", { title: "Hey", message: "Hello there!" });
});

function setLED1on() {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "LED1" };
      // this option instructs the method to create a document if no documents match the filter
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: 1
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
  
}
function setLED1off() {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const filter = { key: "LED1" };
      // this option instructs the method to create a document if no documents match the filter
      const options = { upsert: true };
      const updateDoc = {
        $set: {
          value: 0
        },
      };
      const result = await iot.updateOne(filter, updateDoc, options);
      console.log(
        `${result.matchedCount} document(s) matched the filter, updated ${result.modifiedCount} document(s)`,
      );
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);
}

// res.render("pages/index", {
//   ali: INDEX_PAGE_DATA.ModuleTypeName,
//   sn: INDEX_PAGE_DATA.SerialNumber,
//   mn: INDEX_PAGE_DATA.ModuleName,
//   as: INDEX_PAGE_DATA.ASName,
//   time: INDEX_PAGE_DATA.time,
// });
// }, 300);


// mongodb+srv://alirasa:01470147@cluster0.svtty.mongodb.net/myFirstDatabase?retryWrites=true&w=majority



app.get("/getLED1Status", function (req, res) {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri, {
    useUnifiedTopology: true
  });
  async function run() {
    try {
      await client.connect();

      const database = client.db("data");
      const iot = database.collection("iot");
      const query = { key: "LED1" };
      const options = {
        // sort matched documents in descending order by rating
        sort: { rating: -1 },
        // Include only the `title` and `imdb` fields in the returned document
        projection: { _id: 0, value: 1 },
      };
      const data = await iot.findOne(query, options);
      // since this method returns the matched document, not a cursor, print it directly
      res.status(200).send((data.value).toString());
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);

});