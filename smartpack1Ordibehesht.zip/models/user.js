
const mongoose = require("mongoose");

const user = new mongoose.Schema({
  consumer: { type: String, default: null },
  installer : {type : String},
  serial: {type : String,},
  service: {type : String,},
  pump_status : {type : Boolean},
  air: { type: Boolean },
  water_status: {type : Boolean,default : null},
  smoke: { type: Boolean },
  temp : {type : Number},
  in_temp : {type : Flo,default : 0},
  out_temp : {type : Number,default : 0},
  pac_temp : {type : Number,default : 0},
  in_pressure: { type: Number,default : 0 },
  out_pressure: { type: Number,default : 0 },
  pac_pressure: { type: Number ,default : 0},
  in_flow: { type: Number,default : 0 },
  out_flow : {type : Number,default : 0},
  pac_flow : {type : Number,default : 0},
});

module.exports = mongoose.model("user", user);
