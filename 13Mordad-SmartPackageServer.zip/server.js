const express = require('express')
const app = express()
const port = 4000
const mongoose = require('mongoose');
const user = require('./models/user');
var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.raw());

main().catch(err => console.log(err));

async function main() {
    await mongoose.connect('mongodb://localhost:27017/smartpackage');
}


app.get('/test', (req, res) => {
    res.send("Doodood Madood")
});


app.post('/change', (req, res) => {
    console.log("serial : " + req.body.serial);
    user.findOne({ serial: req.body.serial }, function (err, userPackage) {
        if (err) {
            res.send('Err');
        }
        if (!userPackage) {
            res.send('serial not valid');
        }
        else {
            if (req.body.pump_status) {
                userPackage.pump_status = req.body.pump_status;
            }
            if (req.body.smoke) {
                userPackage.smoke = req.body.smoke;
            }
            if (req.body.water_status) {
                userPackage.water_status = req.body.water_status;
            }
            if (req.body.air) {
                userPackage.air = req.body.air;
            }
            if (req.body.in_pressure) {
                userPackage.in_pressure = req.body.in_pressure;
            }
            if (req.body.out_pressure) {
                userPackage.out_pressure = req.body.out_pressure;
            }
            if (req.body.pac_pressure) {
                userPackage.pac_pressure = req.body.pac_pressure;
            }
            if (req.body.in_flow) {
                userPackage.in_flow = req.body.in_flow;
            }
            if (req.body.out_flow) {
                userPackage.out_flow = req.body.out_flow;
            }
            if (req.body.pac_flow) {
                userPackage.pac_flow = req.body.pac_flow;
            }
            if (req.body.temp) {
                userPackage.temp = req.body.temp;
            }
            if (req.body.consumer) {
                userPackage.consumer = req.body.consumer;
            }
            if (req.body.installer) {
                userPackage.installer = req.body.installer;
            }
            if (req.body.in_temp) {
                userPackage.in_temp = req.body.in_temp;
            }
            if (req.body.out_temp) {
                userPackage.out_temp = req.body.out_temp;
            }
            if (req.body.pac_temp) {
                userPackage.pac_temp = req.body.pac_temp;
            }
            if (req.body.issummer) {
                userPackage.issummer = req.body.issummer;
            }
            if (req.body.status) {
                userPackage.status = req.body.status;
            }
            if (req.body.alarm) {
                userPackage.alarm = req.body.alarm;
            }
            if (req.body.isdegree) {
                userPackage.isdegree = req.body.isdegree;
            }
            if (req.body.temp_setted) {
                userPackage.temp_setted = req.body.temp_setted;
            }
            userPackage.save(function (err) {
                if (err) {
                    res.send('Err on save.');
                }
                res.send('saved');
            });
        }
    })
})



app.listen(port, () => {
    console.log(`Server listening on port ${port}`)
})

app.post('/get', (req, res) => {
    if (!req.body.serial) {
        return res.json('serial needed');
    } else {
        user.findOne({ serial: req.body.serial }, function (err, userPackage) {
            if (err) {
                return res.json('error on server');
            }
            if (!userPackage) {
                return res.json('serial not valid');
            }
            else {
                return res.json(userPackage)
            }
        })
    }

});




