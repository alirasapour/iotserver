const healthUser = require('../models/healthuser');
const MelipayamakApi = require('melipayamak');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
require("dotenv").config();

const username = '09141192639';
const password = 'fhge32m';
const api = new MelipayamakApi(username, password);
const sms = api.sms();

module.exports = function (app) {

  app.post("/health/register", async (req, res) => {
    console.log("/register user from App.")
    try {
      const { first_name, last_name, mobile, age, height, weight, password, blood } = req.body;
      if (!(mobile && password && first_name && last_name && blood && age && height && weight)) {
        return res.json("لطفا تمامی کادر هارا وارد نمایید.");
      }
      if (mobile && password && first_name && last_name && blood && age && height && weight == "undefined") {
        res.json("لطفا تمامی کادر هارا وارد نمایید.");
        return;
      }
      if (!(age <= 140)) {
        res.json("سن وارد شده صحیح نمی باشد.");
        return;
      }
      if (!(weight <= 280)) {
        res.json("وزن وارد شده صحیح نمی باشد.");
        return;
      }
      if (height < 90 || height > 235) {
        res.json("قد شما صحیح نمی باشد.");
        return;
      }
      const oldUser = await healthUser.findOne({ mobile });
      if (oldUser) {
        return res.json("شما قبلا با این شماره تلفن ثبت نام کرده اید.");
      }
      encryptedPassword = password;
      // encryptedPassword = await bcrypt.hash(password, 10);
      const user = await healthUser.create({
        first_name,
        last_name,
        age,
        mobile,
        blood,
        weight,
        height,
        password: encryptedPassword,
      });
      const token = jwt.sign(
        { mobile, password },
        process.env.TOKEN_KEY,
        {
          expiresIn: "380d",
        }
      );
      // save user token
      user.token = token;
      // return new user
      res.json(user);
    } catch (err) {
      console.log(err);
    }
    // Break herer

    // Our register logic ends here
  });


  app.post("/health/login", async (req, res) => {
    try {
      const { mobile, password } = req.body;
      if (!(mobile && password)) {
        return res.json("لطفا تمامی کادر هارا وارد نمایید.");
      }
      const user = await healthUser.findOne({ mobile });
      if (user && user.password == password) {
        const token = jwt.sign(
          { user_id: user._id, mobile },
          process.env.TOKEN_KEY,
          {
            expiresIn: "380d",
          }
        );

        user.token = token;
        res.status(200).json(user);
      }
      return res.json("اطلاعات وارد شده صحیح نمی باشد.");
    } catch (err) {
      console.log(err);
    }

  });


  app.post("/health/forget", async (req, res) => {
    const mobile = (req.body.mobile);
    const user = await healthUser.findOne({ mobile });
    if (user) {
      let texttosend = "رمز عبور شما : " + " " + user.password + "\n" + "\n" + "برای تغییر رمز عبور در قسمت پروفایل وارد بخش تغییر مشخصات شوید." + "\n" + "شرکت فاطر افکار فناور"
      // Send SMS
      const to = mobile;
      const from = '50004001192639';
      sms.send(to, from, texttosend).then(res => {
        return res.json("رمز عبور حساب به شماره تلفن شما ارسال گردید.");
      }).catch(err => {
        return res.json("رمز عبور حساب به شماره تلفن شما ارسال گردید.");
      })
    } else {
      return res.json("کاربری با این شماره ثبت نام نکرده است.");
    }



  });



}